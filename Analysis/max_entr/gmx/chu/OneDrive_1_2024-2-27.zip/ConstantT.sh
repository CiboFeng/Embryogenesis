#!/bin/bash
RUNROOT=`pwd`
protein=chr14
MDPfile="$RUNROOT/Polymer.mdp"
GROMACSDIR="/home/xchu/opt/gromacs-4.5.7_mpich/bin"
PDBDIR="$RUNROOT/PDB"
TOPDIR="$RUNROOT/TOP_ME"
ContactDIR="$RUNROOT/Contact_a"
Tablefile="$RUNROOT/Tables/table_PM.xvg"
Tablepfile="$RUNROOT/Tables/table_ME.xvg"

#Variables
#Lambda=0.01
#Lambda=0.05
#Lambda=0.10
#Lambda=0.20
#Lambda=0.50
 Lambda=1.00
MAXNUM=9
BTIME=500

mkdir -p $RUNROOT/ConstantT
cd $RUNROOT/ConstantT

Nres=577
sigma=0.4
NCPU=4
Radius=`echo "$Nres $sigma" | awk '{print $2/2*(10*$1)**(1.0/3.0)-$2/2}'`
sed "s/NRES/$Nres/g" $RUNROOT/PLUMED/plumed_SR.dat | sed "s/Radius/$Radius/g" > $RUNROOT/plumed_SR.dat
box=`echo "$Radius" | awk '{print $1*2}'`

#for alpha in `seq 0 1 1`
#for alpha in `seq 2 1 3`
#for alpha in `seq 4 1 5`
#for alpha in `seq 6 1 7`
#for alpha in `seq 8 1 9`
#for alpha in `seq 10 1 12`
 for alpha in `seq 13 1 15`
do
	alpha_old=$(($alpha-1))
	
	mkdir -p $RUNROOT/ConstantT/a_$alpha
	cd $RUNROOT/ConstantT/a_$alpha
	if [ "$alpha" == "0" ]; then
		$TOPDIR/TOP.x $RUNROOT/PDBGeneration/Polymer_${Nres}_$sigma.pdb $ContactDIR/Contact_a_${alpha}.dat ${protein}_a_${alpha}
	fi
	TOPfile=$RUNROOT/ConstantT/a_$alpha/${protein}_a_${alpha}.top
	for Temp in 120.28
	do
		mkdir -p $RUNROOT/ConstantT/a_$alpha/$Temp
		cd $RUNROOT/ConstantT/a_$alpha/$Temp
		sed "s/TXTemp/$Temp/g" $MDPfile > $Temp.mdp
		rm list.dat
		for i in `seq 0 1 $MAXNUM`
		do
			mkdir $RUNROOT/ConstantT/a_${alpha}/$Temp/$i
			cd $RUNROOT/ConstantT/a_${alpha}/$Temp/$i
			j=`echo "$i $MAXNUM" | awk '{print $1*($2+1)}'`
			rm -r file 2>/dev/null
cat > ConstantT.sh <<EOF
#$ -S /bin/bash
#$ -cwd
#$ -V
#$ -N a_${alpha}_${Temp}_${i}_PC_BigMDSteps_1
#$ -j y
#$ -o RUN.out
#$ -q cpu_short
#$ -P otherprj
#$ -pe mpich $NCPU
#$ -l h_rt=12:00:00

for k in \`seq 0 1 4\`
do
	mkdir -p $RUNROOT/ConstantT/a_${alpha}/$Temp/$i/\$k
	cd $RUNROOT/ConstantT/a_${alpha}/$Temp/$i/\$k
	l=\$(($j+\$k))
	PDBfile=$PDBDIR/N\$l.gro	
#EM
	$GROMACSDIR/editconf_4.5.7 -f \$PDBfile -o N\${l}_center.gro -box $box $box $box -bt cubic -c
	$GROMACSDIR/grompp_4.5.7 -f $RUNROOT/Polymer_EM.mdp -c N\${l}_center.gro -p $TOPfile -o em.tpr > output 2>&1 
	mpirun -np $NCPU $GROMACSDIR/mdrun_4.5.7 -noddcheck -deffnm em -tableb $RUNROOT/Tables/table.xvg -table $Tablefile -tablep $Tablepfile -plumed $RUNROOT/plumed_SR.dat -pd
#MD
	$GROMACSDIR/grompp_4.5.7 -f ../../$Temp.mdp -c em.gro -p $TOPfile -o md.tpr > output 2>&1 
	mpirun -np $NCPU $GROMACSDIR/mdrun_4.5.7 -noddcheck -s md.tpr -tableb $RUNROOT/Tables/table.xvg -table $Tablefile -tablep $Tablepfile -plumed $RUNROOT/plumed_SR.dat -pd

	echo "0" | $GROMACSDIR/trjconv_4.5.7 -f traj.xtc -s md.tpr -b $BTIME -o ../tmp\$k.xtc
	cd $RUNROOT/ConstantT/a_${alpha}/$Temp/$i
	if [ -e "tmp\$k.xtc" ]; then
		echo "tmp\$k.xtc" >> file
	fi
done

#file=\`awk '{printf "%s ", \$1} END {printf "\n"}' file\`
#trjcat_4.5.7 -f \$file -cat -o trajout.xtc
#rm tmp?.xtc
EOF
			qsub -hold_jid a_${alpha_old}_f_PC_BigMDSteps ConstantT.sh
cat > ConstantT.sh <<EOF
#$ -S /bin/bash
#$ -cwd
#$ -V
#$ -N a_${alpha}_${Temp}_${i}_PC_BigMDSteps_2
#$ -j y
#$ -o RUN.out
#$ -q cpu_short
#$ -P otherprj
#$ -pe mpich $NCPU
#$ -l h_rt=12:00:00

for k in \`seq 5 1 9\`
do
	mkdir -p $RUNROOT/ConstantT/a_${alpha}/$Temp/$i/\$k
	cd $RUNROOT/ConstantT/a_${alpha}/$Temp/$i/\$k
	l=\$(($j+\$k))
	PDBfile=$PDBDIR/N\$l.gro	
#EM
	$GROMACSDIR/editconf_4.5.7 -f \$PDBfile -o N\${l}_center.gro -box $box $box $box -bt cubic -c
	$GROMACSDIR/grompp_4.5.7 -f $RUNROOT/Polymer_EM.mdp -c N\${l}_center.gro -p $TOPfile -o em.tpr > output 2>&1 
	mpirun -np $NCPU $GROMACSDIR/mdrun_4.5.7 -noddcheck -deffnm em -tableb $RUNROOT/Tables/table.xvg -table $Tablefile -tablep $Tablepfile -plumed $RUNROOT/plumed_SR.dat -pd
#MD
	$GROMACSDIR/grompp_4.5.7 -f ../../$Temp.mdp -c em.gro -p $TOPfile -o md.tpr > output 2>&1 
	mpirun -np $NCPU $GROMACSDIR/mdrun_4.5.7 -noddcheck -s md.tpr -tableb $RUNROOT/Tables/table.xvg -table $Tablefile -tablep $Tablepfile -plumed $RUNROOT/plumed_SR.dat -pd

	echo "0" | $GROMACSDIR/trjconv_4.5.7 -f traj.xtc -s md.tpr -b $BTIME -o ../tmp\$k.xtc
	cd $RUNROOT/ConstantT/a_${alpha}/$Temp/$i
	if [ -e "tmp\$k.xtc" ]; then
		echo "tmp\$k.xtc" >> file
	fi
done

#file=\`awk '{printf "%s ", \$1} END {printf "\n"}' file\`
#trjcat_4.5.7 -f \$file -cat -o trajout.xtc
#rm tmp?.xtc
EOF
			qsub -hold_jid a_${alpha_old}_f_PC_BigMDSteps ConstantT.sh
cat > Analysis.sh << EOF
#$ -S /bin/bash
#$ -cwd
#$ -V
#$ -N b_${alpha}_${Temp}_${i}_PC_BigMDSteps
#$ -j y
#$ -o RUN.out
#$ -q cpu_short
#$ -P otherprj

file=\`awk '{printf "%s ", \$1} END {printf "\n"}' file\`
trjcat_4.5.7 -f \$file -cat -o trajout.xtc
rm tmp?.xtc
echo "0" | trjconv_4.5.7 -f trajout.xtc -s $RUNROOT/TOP_ME/Polymer_${Nres}_0.4.pdb -o tmp.pdb
rm -r ?
$RUNROOT/fcal.x tmp.pdb $RUNROOT/Contact_a/Probability.dat $Nres
rm tmp.pdb
rm \#*
EOF
			qsub -hold_jid a_${alpha}_${Temp}_${i}_PC_BigMDSteps_1,a_${alpha}_${Temp}_${i}_PC_BigMDSteps_2 Analysis.sh
			echo "b_${alpha}_${Temp}_${i}_PC_BigMDSteps" >> $RUNROOT/ConstantT/a_$alpha/$Temp/list.dat
		done
		cd $RUNROOT
		sed "s/ALPHA/$alpha/g" f.sh | sed "s/Lambda/$Lambda/g" | sed "s/MAXNUM/$MAXNUM/g" > f_$alpha.sh
		hold_jid=`awk '{printf "%s,", $1} END {printf "%s ",$1}' $RUNROOT/ConstantT/a_$alpha/$Temp/list.dat`
		echo "qsub -hold_jid $hold_jid f_$alpha.sh" > f_$alpha.submit
		qsub -hold_jid $hold_jid f_$alpha.sh
	done
done
